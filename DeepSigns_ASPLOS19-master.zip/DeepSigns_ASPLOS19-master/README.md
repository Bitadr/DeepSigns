# DeepSigns

This repository provides an API for DeepSigs framework. DeepSigns is a generic watermarking framework for IP protection of deep neural networks. The paper 'DeepSigns: A Generic Watermarking Framework for IP Protection of Deep Learning Models' is available on arXiv: https://arxiv.org/abs/1804.00750

